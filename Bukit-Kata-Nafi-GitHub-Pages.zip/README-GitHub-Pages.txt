BUKIT KATA NAFI — GITHUB PAGES

Fail website: index.html

Cara terbitkan:
1. Log masuk ke https://github.com dan cipta repository baharu, contohnya bukit-kata-nafi.
2. Jika menggunakan GitHub Free, pilih Public supaya website boleh diakses oleh sesiapa yang mempunyai pautan.
3. Dalam repository, pilih Add file > Upload files.
4. Muat naik index.html dan .nojekyll daripada pakej ini, kemudian tekan Commit changes.
5. Buka Settings > Pages.
6. Di bawah Build and deployment, pilih Deploy from a branch.
7. Pilih branch main dan folder /(root), kemudian tekan Save.
8. Tunggu beberapa minit. Pautan website akan muncul di bahagian Pages, biasanya dalam bentuk https://NAMA-PENGGUNA.github.io/NAMA-REPOSITORY/.

Nota fungsi:
- Permainan, nota, bunyi, animasi dan soalan dikekalkan daripada fail HTML asal.
- Papan markah menggunakan localStorage, jadi markah setakat ini disimpan pada pelayar/peranti yang digunakan dan tidak dikongsi automatik antara peranti.
- Sambungan pangkalan data kelas asal bergantung pada persekitaran window.claude.use('db'); GitHub Pages tidak menyediakan perkhidmatan itu secara automatik.
